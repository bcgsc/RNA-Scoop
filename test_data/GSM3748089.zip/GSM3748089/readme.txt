There are test input files for RNA-Scoop generated based on GSM3748089 from PMID: 32788667
Lebrigand, et al. High throughput error corrected Nanopore single cell transcriptome sequencing. Nat Commun 2020 Aug 12;11(1):4025.

For more information on using RNA-Scoop, please consult our wiki at:
https://github.com/bcgsc/RNA-Scoop/wiki
